import numpy as np 

w = 15
np.random.seed(10)

y = np.random.uniform(low = 0, high = w , size = 100)